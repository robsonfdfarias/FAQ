# Exemplo de UPLOAD com drag and drop e porcentagem, de múltiplos arquivos com AJAX em Javascript puro

[![N|Solid](https://velhobit.com.br/wp-content/themes/vale/images/logo-velho-bit.jpg)](https://velhobit.com.br)

**Código fonte usado no post vinculado abaixo. O exemplo usa Javascript puro, HTML5 e CSS3. Sem nenhum framework ou pre-processador.**

Para mais detalhes e informações, acesse: https://velhobit.com.br
