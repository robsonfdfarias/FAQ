<html>

<head>

<title>Editor de Texto JavaScript ::: Linha de Código</title>
<style>
    .tabela tr td{
        padding: 10px;
    }
    .table{
        margin:0px;
    }

    #texto{
        min-height: 300px;
        width: 90%;
        box-shadow: 0 0 2px rgba(0,0,0,0.5);
        border:0px solid #000;
        padding: 15px;
    }

    #cores{
        background-color: green;
        cursor: pointer;
        opacity: 0.0;
        position:absolute;
        width: 33px;
    }
</style>
<script language="JavaScript">
    function link() {
        document.execCommand("createLink", true, "https://www.google.com");
    }
    function unlink() {
        document.execCommand("unlink", false, null);
    }
function justificar() {
    document.execCommand("justifyFull");
}
function alinharEsquerda() {
    document.execCommand("justifyLeft");
}
function alinharDireita() {
    document.execCommand("justifyRight");
}
function alinharCentro() {
    document.execCommand("justifyCenter");
}

function italico() {
    document.execCommand("italic", window.getSelection(), null);
}
function negrito() {
    document.execCommand("bold");
}
function sublinhado() {
    document.execCommand("underline", window.getSelection(), null);
}
function cor() {
    var cores = document.getElementById('cores');
    document.execCommand("foreColor", window.getSelection(), cores.value);
}
function backCor() {
    var cores = document.getElementById('cores');
    document.execCommand("backColor", window.getSelection(), cores.value);
}

function tamanhoFont(size) {
    document.execCommand("fontsize", true, size);
}

function copiar() {
    document.execCommand("copy", false, null);
}

function recortar() {
    document.execCommand("cut", false, null);
}

function colar() {
    document.execCommand("paste", false, null);
}

function ordenarLista(){
    document.execCommand("insertOrderedList", false, null);
}

function unOrdenarLista(){
    document.execCommand("insertUnorderedList", false, null);
}

function desfazer(){
    document.execCommand("undo", false, null);
}

function refazer(){
    document.execCommand("redo", false, null);
}

function teste(){
    window.getSelection().getRangeAt(0).insertNode(id_('bold').firstChild);
}

function CssFnctn() {
  document.execCommand('formatblock', false, 'p')
  var listId = window.getSelection().anchorNode.parentNode;
  listId.classList = 'oder2';
}

function insertImg() {
    selection = window.getSelection().toString();
    wrappedselection = '<span class="accent" style="somestyle">' + selection + '</span>';
    //var img = new Image();
    var img = document.createElement('img');
    img.src="imgsGerais/projeto-codigo-01-08-2022.png";
    //console.log(img)
    var imagem = '<img src="imgsGerais/projeto-codigo-01-08-2022.png" width="200" onclick="editImg(this)">';
    document.execCommand('insertHTML', false, imagem);
}

function insertH(valor) {
    selection = window.getSelection().toString();
    console.log(selection)
    wrappedselection = '<'+valor+'>' + selection + '</'+valor+'>';
    //var img = new Image();
    document.execCommand('insertHTML', false, wrappedselection);
}

function insertTable() {
    selection = window.getSelection().toString();
    var table = '<table border="1" cellspacing="0" class="tabela"><tr><td><td><td></tr><tr><td><td><td></tr><tr><td><td><td></tr></table>';
    document.execCommand('insertHTML', false, table);
}

function insertVideo() {
    selection = window.getSelection().toString();
    var table = '<iframe width="560" height="315" src="https://www.youtube.com/embed/dtLXZEuZbeQ?si=HdSO5bFrWUow5eNl" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>';
    var video = window.prompt("Insira no campo abaixo o iframe de incorporação do vídeo do youtube", "");
    document.execCommand('insertHTML', false, video);
}

function insertImg2() {
    selection = window.getSelection().toString();
    wrappedselection = '<span class="accent" style="somestyle">' + selection + '</span>';
    var img = document.createElement('img');
    img.src = "imgsGerais/projeto-codigo-01-08-2022.png";
    
    // Defina o atributo contenteditable da imagem como false para que o usuário não possa editar o texto dentro dela.
    img.contentEditable = false;
    
    // Defina alguns estilos CSS para tornar a imagem redimensionável.
    img.style.width = "200px"; // Largura inicial da imagem
    img.style.height = "auto"; // Altura automática para manter a proporção
    
    // Adicione a imagem ao documento.
    document.execCommand('insertHTML', false, img.outerHTML);
    img.addEventListener('click', function () {
        img.style.width = (img.offsetWidth + 10) + 'px'; // Aumentar a largura em 10 pixels quando a imagem for clicada
    });
}

var imgs = document.getElementsByTagName("img");
for(i=0; i<imgs.length; i++){
    imgs[i].addEventListener("click", function(){
        alert("Clicou")
        imgs[i].setAttribute("style", "border: 1px solid #000;")
    })
}

function editImg(img) {
    var larg = window.prompt("Insira a largura", "");
    var configStyle = img.getAttribute("style");
    console.log(configStyle)
    //
        var opcoes = "";
    if(configStyle==null || configStyle==''){
        //configStyle+="border: 3px solid red;";
        configStyle="border: 3px solid red;";
    }else{
        //opcoes="border: 3px solid red;";
    }

    testa(configStyle, "border: 3px solid red", "border");
    testa(configStyle, larg, "width");
    configStyle = opcoes;
    img.setAttribute("style", configStyle);
    /*if(larg!=null && larg!=''){
        configStyle+="width: "+larg+"px;";
        img.setAttribute("style", configStyle)
    }*/
}
function addHs(){
    document.getElementById('formatH').addEventListener('change', function() {
        var selectedOption = this.children[this.selectedIndex];
        console.log(selectedOption)
       /* var value = this.value;
        var param = selectedOption.getAttribute("data-param");

        document.getElementById('value').textContent = 'value = ' + value;
        document.getElementById('param').textContent = 'data-param = ' + param;*/
    });
}
//addHs();
function testa(configStyle2, valor, arg){
    var op = configStyle2.split(";");
        var opcoes = "";
        console.log(op)
        for(i=0; i<(op.length-1); i++){
            console.log(op[i])
            var opInterno = op[i].split(":")
            if(arg!=null){
                if(opInterno[0]==arg){
                        op[i]=valor;
                    }else{
                        if(i==(op.length-2)){
                            opcoes+=valor;
                        }
                    }
            }
            /*if(opInterno=="border"){
                op[i]="border: 3px solid red";
            }
            
            if(larg!=null && larg!=''){
                if(opInterno=="width"){
                    op[i]="width: "+larg+"px";
                }
            }*/
            opcoes+=op[i]+";";
        }
        console.log(opcoes);
        return opcoes;
}
/*


function editImg(img) {
    var larg = window.prompt("Insira a largura", "");
    var configStyle = img.getAttribute("style");
    console.log(configStyle)
    //
        var opcoes = "";
    if(configStyle==null || configStyle==''){
        //configStyle+="border: 3px solid red;";
        configStyle="border: 3px solid red;";
    }else{
        //opcoes="border: 3px solid red;";
    }

        var op = configStyle.split(";");
        console.log(op)
        for(i=0; i<(op.length-1); i++){
            console.log(op[i])
            var opInterno = op[i].split(":")
            if(opInterno=="border"){
                op[i]="border: 3px solid red";
            }
            
            if(larg!=null && larg!=''){
                if(opInterno=="width"){
                    op[i]="width: "+larg+"px";
                }
            }
            opcoes+=op[i]+";";
        }
        console.log(opcoes);

    configStyle = opcoes;
    img.setAttribute("style", configStyle);
    //if(larg!=null && larg!=''){
    //    configStyle+="width: "+larg+"px;";
    //    img.setAttribute("style", configStyle)
    //}
}*/
</script>

</head>

<body>

<a href="#" onClick="italico()">italico</a><br>
<a href="#" onClick="negrito()">Negrito</a><br>
<a href="#" onClick="sublinhado()">sublinhado</a><br>
<a href="#" onClick="teste()">teste</a><br>
<a href="#" onClick="insertImg()">insertImg</a><br>
<a href="#" onClick="insertTable()">insertTable</a><br>
<a href="#" onClick="insertVideo()">insertVideo</a><br>
<a href="#" onClick="cor()">cor</a>  <!--<input type="color" id="cores" />--><br>
<a href="#" onClick="tamanhoFont(9)">tamanho da fonte</a><br>
<a href="#" onClick="copiar()">Copiar</a><br>
<a href="#" onClick="recortar()">Recortar</a><br>
<a href="#" onClick="colar()">Colar</a><br>
<a href="#" onClick="link()">Inserir Link</a><br>
<a href="#" onClick="unlink()">Remover Link</a><br>
<a href="#" onClick="justificar()">Justificar</a><br>
<a href="#" onClick="alinharCentro()">Alinhar no centro</a><br>
<a href="#" onClick="alinharDireita()">Alinhar a direita</a><br>
<a href="#" onClick="alinharEsquerda()">Alinhar a esquerda</a><br>
<a href="#" onClick="ordenarLista()">Ordenar lista</a><br>
<a href="#" onClick="unOrdenarLista()">UnOrdenar lista</a><br>
<a href="#" onClick="backCor()">COr de fundo</a><br>
<a href="#" onClick="desfazer()">Desfazer</a><br>
<a href="#" onClick="refazer()">Refazer</a><br>
<a href="#" onClick="insertH('h1')">H1</a><br>
<a href="#" onClick="editImg()">Editar Imagem</a><br>
<div id="ferramentas">
    <img src="imgEditor/bold.svg" alt="Colocar em Negrito" onClick="negrito()" />
    <img src="imgEditor/italic.svg" alt="Colocar em Itálico" onClick="italico()" />
    <img src="imgEditor/underline.svg" alt="Colocar em Sublinhado" onClick="sublinhado()" />
    <img src="imgEditor/alignright.svg" alt="Alinhar a direita" onClick="alinharDireita()" />
    <img src="imgEditor/alignleft.svg" alt="Alinhar a esquerda" onClick="alinharEsquerda()" />
    <img src="imgEditor/alignhorizontalcenter.svg" alt="Centralizar" onClick="alinharCentro()" />
    <img src="imgEditor/alignblock.svg" alt="Justificar" onClick="justificar()" />
    <select name="tamFont" id="tamFont">
        <?php
            for($i=1; $i<8; $i++){
                echo '<option value="'.$i.'">'.$i.'</option>';
            }
        ?>
        <option value="" disabled selected>Size</option>
    </select>
    <img src="imgEditor/copy.svg" alt="Copiar" onClick="copiar()" />
    <img src="imgEditor/paste.svg" alt="Colar" onClick="colar()" />
    <img src="imgEditor/cut.svg" alt="Recortar" onClick="recortar()" />
    <img src="imgEditor/defaultbullet.svg" alt="Marcador" onClick="unOrdenarLista()" />
    <img src="imgEditor/defaultnumbering.svg" alt="Numeração" onClick="ordenarLista()" />
    <img src="imgEditor/redo.svg" alt="Refazer" onClick="refazer()" />
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="desfazer()" />
    <img src="imgEditor/insertvideo.svg" alt="Inserir Vídeo" onClick="insertVideo()" />
    <img src="imgEditor/graphic.svg" alt="Inserir Imagem" onClick="insertImg()" />
    <img src="imgEditor/inserttable.svg" alt="Inserir tabela" onClick="insertTable()" />
    <input type="color" id="cores" />
    <img src="imgEditor/color.svg" alt="Mudar a cor do texto" onClick="cor()" />
    <img src="imgEditor/inserthyperlinkcontrol.svg" alt="Inserir hiperlink" onClick="link()" />
    <img src="imgEditor/inserthyperlinkcontrol.svg" alt="Remover hiperlink" onClick="unlink()" />
    <select name="formatH" id="formatH">
        <option value="h1">H1</option>
        <option value="h2">H2</option>
        <option value="h3">H3</option>
        <option value="h4">H4</option>
        <option value="h5">H5</option>
    </select>
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="editImg()" />
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="editImg()" />
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="editImg()" />
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="editImg()" />
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="editImg()" />
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="editImg()" />
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="editImg()" />
    <img src="imgEditor/undo.svg" alt="Desfazer" onClick="editImg()" />
</div>
<div id="texto" contenteditable="true">RObson Ferreira de Farias</div>

<div id="painelInseriVideo">
    <input type="text" id="url">
    <div id="videoVisualiza" contentEditable="true"></div>
    <button id="inserirVideo" onclick="insertVi()">Inserir</button>
</div>

<!--
<p>
  An example demonstrating the use of the
  <code>&lt;input type="color"&gt;</code> control.
</p>

<label for="color-picker">Color:</label>
<input type="color" value="#ff0000" id="color-picker" />

<p>
  Watch the paragraph colors change when you adjust the color picker. As you
  make changes in the color picker, the first paragraph's color changes, as a
  preview (this uses the <code>input</code> event). When you close the color
  picker, the <code>change</code> event fires, and we detect that to change
  every paragraph to the selected color.
</p>

        -->

<input type="file" id="inputFile" accept="image/*">
    <canvas id="canvas"></canvas>

    <script>
        const inputFile = document.getElementById('inputFile');
        const canvas = document.getElementById('canvas');
        const ctx = canvas.getContext('2d');

        inputFile.addEventListener('change', function () {
            const file = inputFile.files[0];
            if (file) {
                const reader = new FileReader();

                reader.onload = function (e) {
                    const img = new Image();
                    img.src = e.target.result;

                    img.onload = function () {
                        // Defina o tamanho do canvas igual ao tamanho da imagem
                        canvas.width = img.width;
                        canvas.height = img.height;

                        // Desenhe a imagem no canvas
                        ctx.drawImage(img, 0, 0);
                    };
                };

                reader.readAsDataURL(file);
            }
        });
    </script>

<script type="text/javascript">
    (function () {
        document.getElementById('formatH').addEventListener('change', function() {
            var selectedOption = this.children[this.selectedIndex];
            console.log(selectedOption)
            var value = this.value;
            var param = selectedOption.getAttribute("data-param");
            insertH(value)
            console.log(value)
            console.log(param)

            /*document.getElementById('value').textContent = 'value = ' + value;
            document.getElementById('param').textContent = 'data-param = ' + param;*/
        });
        document.getElementById('tamFont').addEventListener('change', function() {
            var selectedOption = this.children[this.selectedIndex];
            console.log(selectedOption)
            var value = this.value;
            var param = selectedOption.getAttribute("data-param");
            tamanhoFont(value)
            console.log(value)
            console.log(param)

            /*document.getElementById('value').textContent = 'value = ' + value;
            document.getElementById('param').textContent = 'data-param = ' + param;*/
        });
    })();


    

var cores = document.getElementById('cores');
//cores.addEventListener("input", updateFirst, false);
cores.addEventListener("change", watchColorPicker, false);

function watchColorPicker(event) {
  document.querySelectorAll("p").forEach((p) => {
    console.log(event.target.value)
    console.log(cores.select())
    
  });
}


let colorPicker;
const defaultColor = "#0000ff";

window.addEventListener("load", startup, false);

function startup() {
  colorPicker = document.querySelector("#cores");
  colorPicker.value = defaultColor;
  colorPicker.addEventListener("input", cor, false);
  //colorPicker.addEventListener("change", updateAll, false);
  colorPicker.select();
}

function insertVi(){
    var url = document.getElementById('url').value;
    var vizualiza = document.getElementById('videoVisualiza');
    vizualiza.innerHTML = ifrm;
}

    </script>




<!-- 1. The <iframe> (and video player) will replace this <div> tag. -->
<div id="player"></div>

<script>
  // 2. This code loads the IFrame Player API code asynchronously.
  var tag = document.createElement('script');

  tag.src = "https://www.youtube.com/iframe_api";
  var firstScriptTag = document.getElementsByTagName('script')[0];
  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

  // 3. This function creates an <iframe> (and YouTube player)
  //    after the API code downloads.
  var player;
  function onYouTubeIframeAPIReady() {
    player = new YT.Player('player', {
      height: '360',
      width: '640',
      videoId: 'jXSNobmB7u4',
      events: {
        'onReady': onPlayerReady,
        'onStateChange': onPlayerStateChange
      }
    });
  }
  function onYouTubeIframeAPIReady2() {
    player = new YT.Player('player', {
      height: '360',
      width: '640',
      videoId: 'fMyzSrDoT-E',
      events: {
        'onReady': onPlayerReady,
        'onStateChange': onPlayerStateChange
      }
    });
  }
  player.events.onReady = 'fMyzSrDoT-E';

  // 4. The API will call this function when the video player is ready.
  function onPlayerReady(event) {
    event.target.playVideo();
  }

  // 5. The API calls this function when the player's state changes.
  //    The function indicates that when playing a video (state=1),
  //    the player should play for six seconds and then stop.
  var done = false;
  function onPlayerStateChange(event) {
    if (event.data == YT.PlayerState.PLAYING && !done) {
      setTimeout(stopVideo, 6000);
      done = true;
    }
  }
  function stopVideo() {
    player.stopVideo();
  }
</script>


</body>
</html>